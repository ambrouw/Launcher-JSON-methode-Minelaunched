Attention:
Le fichier index.php est à mettre à la racine du répertoire contenant les fichiers à faire installer au launcher